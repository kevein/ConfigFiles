#!/usr/bin/python
import os
# Make sure __file__ is defined
# http://groups.google.com/group/comp.lang.python/browse_frm/thread/cf2a718a50f9bb52/fb754e84298513db
print "__file__: %s" % os.path.basename(__file__)

