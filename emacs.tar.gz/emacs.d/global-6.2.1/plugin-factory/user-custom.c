#include "parser.h"

void
parser(const struct parser_param *param)
{
	param->warning("This is a skeleton function. Nothing has been implemented yet.");
}
